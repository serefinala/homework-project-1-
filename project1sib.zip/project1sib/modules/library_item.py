class LibraryItem():

    def __init__(self, title=None, upc=None, subject=None):
        self.title = title
        self.upc = upc
        self.subject = subject
